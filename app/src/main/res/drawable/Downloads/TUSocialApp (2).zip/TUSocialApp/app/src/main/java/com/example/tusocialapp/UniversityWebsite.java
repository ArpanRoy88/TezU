package com.example.tusocialapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.webkit.WebView;

public class UniversityWebsite extends AppCompatActivity {

    Toolbar myToolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_university_website);


        myToolbar = findViewById(R.id.my_toolbar);
        myToolbar.setTitle("TU Website");
        setSupportActionBar(myToolbar);

        //setting up webview
        WebView webView = new WebView(this);
        setContentView(webView);
        webView.loadUrl("http://www.tezu.ernet.in/");
    }
}