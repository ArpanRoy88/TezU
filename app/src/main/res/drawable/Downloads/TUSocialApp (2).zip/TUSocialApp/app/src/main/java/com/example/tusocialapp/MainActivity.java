package com.example.tusocialapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {

    CircleImageView navHeaderProfileIcon;
    Toolbar myToolbar;

    String email,email2,email3;

    private FirebaseAuth mFirebaseAuth;
    private FirebaseUser user;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;



    private TextView txtLoggedInAs;
    private TextView txtNavHeaderEmail,txtNavHeaderUserName;

    BottomNavigationView bottomNavigationView;

    NavigationView navigationView;
    ActionBarDrawerToggle toggle;
    DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //init
        mFirebaseAuth = FirebaseAuth.getInstance();
        user = mFirebaseAuth.getCurrentUser();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Student");


        //txtLoggedInAs = findViewById(R.id.txtLoggedInAs);

        navigationView = findViewById(R.id.myNavigationDrawer);
        drawerLayout = findViewById(R.id.drawer);

        //adding toolbar
        myToolbar = findViewById(R.id.my_toolbar);
        myToolbar.setTitle("TezU");
        setSupportActionBar(myToolbar);

        //setting the toggle
        toggle = new ActionBarDrawerToggle(this,drawerLayout,myToolbar,R.string.open,R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        sendEmail();

        //navigation onclick listener
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                switch (menuItem.getItemId()){

                    case R.id.myEvents:
                        Toast.makeText(getApplicationContext(),"Home",Toast.LENGTH_SHORT).show();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.TUNotifications:

                        Toast.makeText(getApplicationContext(),"Notifications",Toast.LENGTH_SHORT).show();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.TUWebsite:

                        //Toast.makeText(getApplicationContext(),"Website",Toast.LENGTH_SHORT).show();
                        Intent website = new Intent(getApplicationContext(),UniversityWebsite.class);
                        startActivity(website);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.AboutUs:

                        Toast.makeText(getApplicationContext(),"About",Toast.LENGTH_SHORT).show();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.EmergencyContacts:

                        Toast.makeText(getApplicationContext(),"Emergency",Toast.LENGTH_SHORT).show();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;

                    case R.id.Logout:

                        logout();
                        //drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                }
                return true;
            }
        });

        bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(navListener);
        getSupportFragmentManager().beginTransaction().replace(R.id.FragmentContainer,
                new EventFragment()).commit();


    }

    @Override
    protected void onStart() {
        checkUserStatus();
        super.onStart();
    }


    //add click listener to bottom navigation

    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    Fragment selectFragment = null;

                    switch (menuItem.getItemId()){

                        case R.id.eventBottomNavigation:
                            selectFragment = new EventFragment();
                            break;
                        case R.id.EMagazineBottomNavigation:
                            selectFragment = new EMagazineFragment();
                            break;
                        case R.id.DiscussionBottomNavigation:
                            selectFragment = new DiscussionForumFragment();
                            break;
                        case R.id.BuySellBottomNavigation:
                            selectFragment = new BuySellFragment();
                            break;
                    }
                    getSupportFragmentManager().beginTransaction().replace(R.id.FragmentContainer,
                            selectFragment).commit();

                    return true;
                }
            };

    // navigation drawer header update
    private void updateHeader(){

        navigationView = findViewById(R.id.myNavigationDrawer);
        View headerView = navigationView.getHeaderView(0);

        txtNavHeaderUserName = headerView.findViewById(R.id.drawerHeaderUserName);
        txtNavHeaderEmail = headerView.findViewById(R.id.drawerHeaderUserEmail);
        navHeaderProfileIcon = headerView.findViewById(R.id.drawerHeaderProfilePic);

        txtNavHeaderEmail.setText(user.getEmail());

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    if (ds.child("Email").getValue().equals(user.getEmail())) {

                        txtNavHeaderUserName.setText(ds.child("StudentName").getValue(String.class));
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        navHeaderProfileIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(MainActivity.this,"CLICKED", Toast.LENGTH_SHORT).show();

                Intent profileIcon = new Intent(MainActivity.this,UserProfile.class);

                email2 = txtNavHeaderEmail.getText().toString();
                profileIcon.putExtra("Email",email2);

                startActivity(profileIcon);
            }
        });

    }
    protected void sendEmail(){
        Intent getIntent = getIntent();
        email = getIntent.getStringExtra("Email");

        email3 = email;
        //Toast.makeText(MainActivity.this,"Email:" + email, Toast.LENGTH_SHORT).show();

    }

    private void checkUserStatus(){
        //get current user
        user = mFirebaseAuth.getCurrentUser();

        if (user != null){
            //user is signed in
            //txtLoggedInAs.setText(user.getEmail());

            //Toast.makeText(MainActivity.this,"User found", Toast.LENGTH_SHORT).show();

            sendEmail();
            updateHeader();

        }
        else {
            //user not signed in
            //  Toast.makeText(MainActivity.this,"Not Found", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(MainActivity.this,MainLogin.class));
            finish();
        }
    }


    //logout function
    public void logout() {

        FirebaseAuth.getInstance().signOut();
        Intent gotologin = new Intent(getApplicationContext(),MainLogin.class);
        gotologin.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(gotologin);

        finish();
    }
}