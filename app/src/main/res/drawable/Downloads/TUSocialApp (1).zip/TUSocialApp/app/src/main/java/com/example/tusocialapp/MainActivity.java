package com.example.tusocialapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {

    CircleImageView toolbarProfileIcon;
    Toolbar myToolbar;

    String email,email2;

    private FirebaseAuth mFirebaseAuth;

    private TextView txtLoggedInAs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbarProfileIcon = findViewById(R.id.circularToolbarProfileImage);
        txtLoggedInAs = findViewById(R.id.txtLoggedInAs);

        myToolbar = findViewById(R.id.my_toolbar);
        myToolbar.setTitle("TezU");
        setSupportActionBar(myToolbar);

        sendEmail();

        toolbarProfileIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Toast.makeText(MainActivity.this,"CLICKED", Toast.LENGTH_SHORT).show();

                Intent profileIcon = new Intent(MainActivity.this,UserProfile.class);

                email2 = txtLoggedInAs.getText().toString();
                profileIcon.putExtra("Email",email2);

                startActivity(profileIcon);


            }
        });

        //init
        mFirebaseAuth = FirebaseAuth.getInstance();

    }

    private void checkUserStatus(){
        //get current user
        FirebaseUser user = mFirebaseAuth.getCurrentUser();

        if (user != null){
            //user is signed in
            txtLoggedInAs.setText(user.getEmail());

         //   Toast.makeText(MainActivity.this,"User found", Toast.LENGTH_SHORT).show();

            sendEmail();
        }
        else {
            //user not signed in
          //  Toast.makeText(MainActivity.this,"Not Found", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(MainActivity.this,MainLogin.class));
            finish();
        }
    }

    @Override
    protected void onStart() {
        checkUserStatus();
        super.onStart();
    }

    protected void sendEmail(){
        Intent getIntent = getIntent();
        email = getIntent.getStringExtra("Email");

        email2 = email;
        //Toast.makeText(MainActivity.this,"Email:" + email, Toast.LENGTH_SHORT).show();

    }
}