package com.example.tusocialapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import de.hdodenhof.circleimageview.CircleImageView;

public class UserProfile extends AppCompatActivity {

    Toolbar myToolbar;

    TextView txtstudentName;
    TextView txtstudentSchool;
    TextView txtstudentDepartment;
    TextView txtstudentProgramme;
    TextView txtstudentEmail;
    TextView txtstudentRollNumber;
    TextView txtstudentContact;
    TextView txtstudentGender;
    TextView txtstudentHostel;

    CircleImageView studentProfilePicture;

    String email,password;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        myToolbar = findViewById(R.id.my_toolbar);
        myToolbar.setTitle("Profile");
        setSupportActionBar(myToolbar);

        Intent getIntent = getIntent();
        email = getIntent.getStringExtra("Email");

        //Toast.makeText(UserProfile.this,"Email is" +email ,Toast.LENGTH_SHORT).show();

        txtstudentName = findViewById(R.id.profileStudentName);
        txtstudentSchool  = findViewById(R.id.profileStudentSchool);
        txtstudentDepartment = findViewById(R.id.profileStudentDepartment);
        txtstudentProgramme = findViewById(R.id.profileStudentProgramme);
        txtstudentEmail = findViewById(R.id.profileStudentEmail);
        txtstudentRollNumber = findViewById(R.id.profileStudentRollNumber);
        txtstudentContact = findViewById(R.id.profileStudentContactNumber);
        txtstudentGender = findViewById(R.id.profileStudentGender);
        txtstudentHostel = findViewById(R.id.profileStudentHostel);

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Student");

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for (DataSnapshot ds : dataSnapshot.getChildren()){
                    if (ds.child("Email").getValue().equals(email)){


                        //Toast.makeText(UserProfile.this,"Matching",Toast.LENGTH_SHORT).show();

                        txtstudentName.setText(ds.child("StudentName").getValue(String.class));
                        txtstudentSchool.setText(ds.child("School").getValue(String.class));
                        txtstudentDepartment.setText(ds.child("Department").getValue(String.class));
                        txtstudentProgramme.setText(ds.child("Programme").getValue(String.class));
                        txtstudentEmail.setText(email);
                        txtstudentRollNumber.setText(ds.child("RollNumber").getValue(String.class));
                        txtstudentContact.setText(ds.child("Contact").getValue(String.class));
                        txtstudentGender.setText(ds.child("Gender").getValue(String.class));
                        txtstudentHostel.setText(ds.child("Hostel").getValue(String.class));

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    //actionbar menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.user_profile_menu,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){

            case R.id.EditProfile:

                Toast.makeText(UserProfile.this,"Edit Profile",Toast.LENGTH_SHORT).show();

                startActivity(new Intent(getApplicationContext(),EditProfileActivity.class));
                break;

            case R.id.ResetPassword:

                Toast.makeText(UserProfile.this,"Reset",Toast.LENGTH_SHORT).show();
                break;

            case R.id.Logout:

                logout();
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    //logout function
    public void logout() {

        FirebaseAuth.getInstance().signOut();
        Intent gotologin = new Intent(getApplicationContext(),MainLogin.class);
        gotologin.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(gotologin);

        finish();
    }
}